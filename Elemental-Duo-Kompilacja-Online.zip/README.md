# Elemental Duo

Dwuwymiarowa gra logiczno-platformowa w C++17 z SFML 3.0.2. SFML obsługuje okno,
rysowanie, tekst, klawiaturę i odtwarzanie krótkich dźwięków. Ruch, kolizje i
modele fizyczne są częścią kodu gry.

## Uruchomienie w Visual Studio Community 2022

1. Rozpakuj całe archiwum. Jeśli masz mało miejsca na C:, rozpakuj je na dysk D:.
2. W Visual Studio Installer sprawdź, czy masz obciążenie **Programowanie
   aplikacji klasycznych w języku C++**, w tym MSVC, Windows SDK oraz
   **Narzędzia języka C++ CMake dla systemu Windows**. Zainstaluj też Git, jeśli
   polecenie `git --version` nie działa w terminalu.
3. W Visual Studio użyj **Plik → Otwórz → Folder**. Wskaż folder
   `Elemental-Duo`, w którym znajduje się `CMakeLists.txt`.
4. Wybierz konfigurację **Windows x64 (Release)**. Przy pierwszej konfiguracji
   CMake pobierze SFML oraz biblioteki potrzebne SFML. Potrzebujesz wtedy
   połączenia z internetem. Pliki kompilacji zapisują się w podfolderze
   `out/build/`, na dysku z rozpakowanym projektem.
5. Na pasku uruchamiania wybierz **ElementalDuo.exe**. Użyj **Ctrl+F5**,
   aby zbudować i uruchomić grę. Pierwsza kompilacja obejmuje też biblioteki.

Jeśli Visual Studio zgłosi brak Git po jego instalacji, zamknij program i otwórz
go ponownie, aby wczytał aktualną ścieżkę systemową.

### Budowanie z terminala deweloperskiego x64

W folderze projektu wykonaj:

```powershell
cmake --preset windows-x64
cmake --build --preset windows-x64
ctest --preset windows-x64
.\out\build\windows-x64\ElementalDuo.exe
```

Folder `assets` jest kopiowany obok pliku wykonywalnego automatycznie.
Archiwum zawiera projekt źródłowy do samodzielnego zbudowania.

## Sterowanie

| Klawisz | Działanie |
| --- | --- |
| Enter | Start lub ponowna rozgrywka po zakończeniu |
| A/D lub ←/→ | Ruch, a w menu wybór poziomu |
| Spacja, W lub ↑ | Skok lub szybsze wynurzanie |
| E | Interakcja przy przełączniku |
| R | Restart od początku aktualnego poziomu |
| Esc | Powrót do menu |
| M | Włączenie lub wyłączenie dźwięku |

Upadek i kontakt z aktywną strefą zagrożenia cofają do początku aktualnej
zagadki. Aby przejść całą grę, zacznij od Podwodnej przeprawy.

## Poziomy i zagadki

| Poziom | Pierwsza zagadka | Druga zagadka |
| --- | --- | --- |
| Podwodna przeprawa | Przepłyń zbiornik z prądem, oporem i wypornością | Zmień poziom wody zaworem, żeby boja uruchomiła czujnik bramy |
| Kraina lodu | Nabierz pędu na śliskiej pochylni i przeskocz szczelinę | Zamroź część zbiornika i wykorzystaj lód jako rozbieg |
| Świątynia wiatru | Wznieś się w kominie powietrznym i wyląduj na półce | Odwróć kierunek działania różnicy ciśnień i dostań się na wyższą półkę |
| Laboratorium elektromagnetyczne | Przyciągnij skrzynię do styków zasilających bramę | Domknij obwód przewodzącą skrzynią, aby wyłączyć strefę pod napięciem |

## Struktura kodu

- `src/Levels.cpp` definiuje osiem zagadek w czterech poziomach.
- `src/Game.hpp` i `src/Game.cpp` definiują stan gry i fizykę ze stałym krokiem
  1/120 s. Od nich zależy test automatyczny, więc można go zbudować bez SFML.
- `src/Presentation.cpp` rysuje interfejs, postać i animowane tła.
- `src/main.cpp` obsługuje okno, zdarzenia i syntetyzowane dźwięki.
- `tests/Playthrough.cpp` wykonuje pełne przejście i sprawdza reset oraz
  kluczowe mechaniki.

Grafika jest rysowana programowo. Licencja czcionki DejaVu znajduje się w
`assets/DejaVu-LICENSE.txt`. Plik `.gitignore` pomija katalogi kompilacji
i lokalne ustawienia Visual Studio.

Jeśli projekt ma trafić do wspólnego repozytorium, dodaj zawartość katalogu
`Elemental-Duo` do repozytorium zespołu razem z plikiem `.gitignore`. Gdy
zaczynacie nowe repozytorium, użyj w tym katalogu `git init`.
