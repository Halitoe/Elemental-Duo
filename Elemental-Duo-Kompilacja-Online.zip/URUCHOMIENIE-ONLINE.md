# Kompilacja online na Windowsie

1. Rozpakuj archiwum. Na GitHubie utwórz **prywatne** repozytorium i dodaj
   README przy tworzeniu, żeby miało domyślną gałąź.
2. Otwórz **Add file → Upload files** i dodaj zawartość rozpakowanego
   katalogu. Po zapisie na głównej stronie repozytorium obok siebie mają być
   `CMakeLists.txt`, `src`, `assets`, `tests` oraz `.github`.
3. Jeśli przeglądarka pominęła `.github`, wybierz **Add file → Create new
   file**, w polu nazwy wpisz `.github/workflows/windows.yml` i wklej zawartość
   pliku o tej samej ścieżce z rozpakowanego archiwum. Zapisz przez
   **Commit changes**. Workflow uruchomi się po zatwierdzeniu zmian.
4. W zakładce **Actions** wejdź w najnowsze uruchomienie
   **Build Elemental Duo for Windows**. Jeśli kompilacja się nie uruchomiła,
   wybierz workflow i kliknij **Run workflow**.
5. Po zielonym wyniku z sekcji **Artifacts** pobierz
   **Elemental-Duo-Windows-x64**. Rozpakuj pobrane archiwum i uruchom
   `ElementalDuo.exe` z tego samego katalogu co `assets`.

Kompilacja i testy odbywają się na serwerze GitHuba. Wynik jest przeznaczony
dla Windows x64. Pliki źródłowe nie muszą pozostać na Twoim dysku po wgraniu.
