#pragma once

#include "Game.hpp"

#include <SFML/Graphics.hpp>
#include <array>
#include <filesystem>

namespace elemental {

constexpr float sceneTop = 80;
constexpr float viewHeight = 594;
inline constexpr std::array<const wchar_t*,4> levelNames = {
    L"Podwodna przeprawa", L"Kraina lodu", L"Świątynia wiatru", L"Laboratorium"
};

class Presentation {
public:
    bool loadFont(const std::filesystem::path& path);
    void draw(sf::RenderWindow& window, const Game& game, float seconds,
              std::size_t selected, bool muted) const;
    static Rect menuTile(std::size_t index);
private:
    sf::Font font;
};

}
